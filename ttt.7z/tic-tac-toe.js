/*  A simple Tic-Tac-Toe game
Players 'X' and 'O' take turn inputing their position on the command line using numbers 1-9
1 | 2 | 3
---------
4 | 5 | 6
---------
7 | 8 | 9
*/

// importing user import library
// missed ({sigint: true});
const prompt = require('prompt-sync')({sigint: true});

let board = {
    1: ' ', 2: ' ', 3: ' ',
    4: ' ', 5: ' ', 6: ' ',
    7: ' ', 8: ' ', 9: ' '
};

// TODO: update the gameboard with the user input
function markBoard(position, mark) {
    board[position] = mark;
}

// TODO: print the game board as described at the top of this code skeleton
// Will not be tested in Part 1
function printBoard() {
    console.log(`
        ${board[1]} | ${board[2]} | ${board[3]}
        ----------
        ${board[4]} | ${board[5]} | ${board[6]}
        ----------
        ${board[7]} | ${board[8]} | ${board[9]}
        `);
}


// TODO: check for wrong input, this function should return true or false.
// true denoting that the user input is correct
// you will need to check for wrong input (user is entering invalid position) or position is out of bound
// another case is that the position is already occupied
// position is an input String
function validateMove(position) {
    let positionNum= Number(position);
    if(isNaN(positionNum) || positionNum<1 || positionNum > 9){
        console.log("Invalid position or Wrong input");
        return false;
    }
    if(board[positionNum] !== ' '){
        console.log("Position is already occupied");
            return false;
    }
    return true;
}

// TODO: list out all the combinations of winning, you will neeed this
// one of the winning combinations is already done for you
let winCombinations = [
    [1, 2, 3],[4, 5, 6], [7, 8, 9],[1, 4, 7], [2, 5, 8], [3, 6, 9], [1, 5, 9], [3, 5, 7]
];

// TODO: implement a logic to check if the previous winner just win
// This method should return with true or false
function checkWin(player) {
    let player1 = player.toUpperCase();
    for (let i = 0; i < winCombinations.length; i++) {
        if (board[winCombinations[i][0]] == player1 && board[winCombinations[i][1]] == player1 && board[winCombinations[i][2]] == player1) {
            return true;
        }
    }
    return false;
    
}

// TODO: implement a function to check if the game board is already full
// For tic-tac-toe, tie bascially means the whole board is already occupied
// This function should return with boolean
function checkFull() {
    for (let a in board) {
        if (board[a] === ' ') {
            return false;
        }
    }
    return true;
}

// *****************************************************
// Copy all your code/fucntions in Part 1 to above lines
// (Without Test Cases)
// *****************************************************


// TODO: the main part of the program
// This part should handle prompting the users to put in their next step, checking for winning or tie, etc
function playTurn(player) {
     while(winnerIdentified == false){
        let position = prompt(`Player ${currentTurnPlayer}, please enter your position: `);
        if(!validateMove(position)){
            console.log("This is not a valid move")
            currentTurnPlayer = (currentTurnPlayer === 'O') ? 'X' : 'O';
        }
        else if(validateMove(position)){
                    markBoard(position, currentTurnPlayer);
                    printBoard();
                    if(checkFull(board)){
                        console.log("Tie!");
                        winnerIdentified = true;
                    }
                    else if(checkWin(currentTurnPlayer)){
                        console.log(`Player ${currentTurnPlayer} wins!`);
                        winnerIdentified = true;
                        }
            }
            currentTurnPlayer = (currentTurnPlayer === 'O') ? 'X' : 'O';
        }
        PlayAgain();
    }

function PlayAgain(){
    while(winnerIdentified==true){
    console.log("Do you want to play again? (Y/N)");
    let DoPlay = prompt()
    DoPlay = DoPlay.toUpperCase();
    if(DoPlay !== "Y" && DoPlay !=="N"){
        console.log("Please enter Y or N");
    }
    else if(DoPlay === "Y"){
        winnerIdentified = false;
        currentTurnPlayer = 'X';
        board = {
            1: ' ', 2: ' ', 3: ' ',
            4: ' ', 5: ' ', 6: ' ',
            7: ' ', 8: ' ', 9: ' '
        };
        playTurn(currentTurnPlayer);
        return;
        }
    else if(DoPlay === "N"){
        console.log("Thank you for playing!");
        return;
        }
    }
    }

// entry point of the whole program
console.log('Game started: \n\n' +
    ' 1 | 2 | 3 \n' +
    ' --------- \n' +
    ' 4 | 5 | 6 \n' +
    ' --------- \n' +
    ' 7 | 8 | 9 \n');

let winnerIdentified = false;
var currentTurnPlayer = 'X';

while (!winnerIdentified){
    playTurn(currentTurnPlayer);

}


// Bonus Point: Implement the feature for the user to restart the game after a tie or game over
